int x;
char *p;
char b[10];
int ** q;
char *b[10];
char (*c)[10];
int **d[10];
int *(*e)[10];

char (*b)[10];
char *c[10];
int *(*d)[10];
int **e[10];

int f();
char *g(); 
char a()[10];
int b[10]();
int **h();
char (*p)();
int *(*q)();






int x, a[10];

int f(int x, int y) {

	int y;
	{
		int w;
		w = w + z;
		y = g();
	}

	w = a[x];
}

int x, a[5];
int f(int x) {}



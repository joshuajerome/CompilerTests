int f(int x, int y) {}

int f (int x, int y) {}

int f(int x) {}

char f(char x) {}


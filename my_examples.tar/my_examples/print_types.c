int x;
char *p;
char a[10];
int **q;
char *b[10];
char (*c)[10];
int **d[10];
int *(*e)[10];

int f();
char *g();
char a()[10];
int b[10]();
int **h();
char (*p)();
int *(*q)();

